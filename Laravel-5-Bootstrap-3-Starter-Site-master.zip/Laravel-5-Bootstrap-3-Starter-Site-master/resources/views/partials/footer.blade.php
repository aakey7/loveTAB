<div id="footer">
    <div class="container">
        <p class="text-muted credit"><span style="text-align: left; float: left">&copy; 2015 <a href="#">Laravel
                    5 Starter Site</a></span> <span class="hidden-phone"
                                                    style="text-align: right; float: right">Powered by: <a
                        href="http://laravel.com/" alt="Laravel 5.1">Laravel 5.1</a></span></p>
    </div>
</div>