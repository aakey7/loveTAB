<?php

return [
    'articlecategories' => 'Article categories',


];