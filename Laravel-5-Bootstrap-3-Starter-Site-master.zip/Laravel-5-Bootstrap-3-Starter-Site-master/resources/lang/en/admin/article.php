<?php

return [
    'article' => 'Article',
    'introduction' => 'Introduction',
    'content' => 'Content',
    'source' => 'Source',
    'picture' => 'Picture',
    'category' => 'Category',

];