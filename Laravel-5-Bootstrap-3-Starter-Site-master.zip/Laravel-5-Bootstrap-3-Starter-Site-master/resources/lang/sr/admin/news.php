<?php

return [
    'news' => 'Новости',
    'introduction' => 'Уводна',
    'content' => 'Цијела',
    'source' => 'Извор',
    'picture' => 'Слика',
    'category' => 'Категорија',

];