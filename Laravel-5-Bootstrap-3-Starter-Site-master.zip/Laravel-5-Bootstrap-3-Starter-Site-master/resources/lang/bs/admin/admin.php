<?php

return [
	'settings' => 'Podešavanja',
	'homepage' => 'Povratak na sajt',
	'home' => 'Početna',
    'welcome' => 'Dobro došli',
    'action' => 'Akcije',
    'back' => 'Povratak',
    'created_at' => 'Kreirano',
    'language' => 'Jezik',
    'yes'       => 'Da',
    'no'        =>  'Ne',
    'view_detail' => 'Detalji',
    'news_categories' => 'Kategorije novosti',
    'news_items' => 'Novosti',
    'photo_albums' => 'Foto albumi',
    'photo_items' => 'Fotografije',
    'video_albums' => 'Video albumi',
    'video_items' => 'Videoi',
    'users' => 'Korisnici',
	
	];